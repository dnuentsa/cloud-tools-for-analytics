
    DROP TABLE IF EXISTS ratings;
    DROP TABLE IF EXISTS  trips ;
    DROP TABLE IF EXISTS  cars; 
    DROP TABLE IF EXISTS  customers;
    DROP TABLE IF EXISTS  cities;
    
CREATE TABLE IF NOT EXISTS cities (
        city_id INT PRIMARY KEY,
        city_name VARCHAR(255),
        city_lat NUMERIC(10,6),
        city_long NUMERIC(10,6)
    );
CREATE TABLE IF NOT EXISTS customers (
        id INT PRIMARY KEY,
        name VARCHAR(255),
        email VARCHAR(255) NOT NULL,
        city_id INT,
        registration_date DATE,
        FOREIGN KEY (city_id) REFERENCES cities(city_id)
    );
CREATE TABLE IF NOT EXISTS cars (
        id INT PRIMARY KEY,
        brand VARCHAR(255),
        model VARCHAR(255),
        year INT,
        city_id INT,
        daily_price NUMERIC(10,6),
        FOREIGN KEY (city_id) REFERENCES cities(city_id)
      );
CREATE TABLE IF NOT EXISTS trips (
        id INT PRIMARY KEY,
        pickup_time TIMESTAMP,
        dropoff_time TIMESTAMP,
        pickup_lon NUMERIC(10,6),
        pickup_lat NUMERIC(10,6),
        dropoff_lon NUMERIC(10,6),
        dropoff_lat NUMERIC(10, 6),
        distance FLOAT,
        revenue FLOAT,
        car_id INT,
        customer_id INT,
        FOREIGN KEY (car_id) REFERENCES cars(id),
        FOREIGN KEY (customer_id) REFERENCES customers(id)
    );
CREATE TABLE IF NOT EXISTS ratings (
        id INT PRIMARY KEY,
        rating INT,
        trip_id INT,
        FOREIGN KEY (trip_id) REFERENCES trips(id)
    );
